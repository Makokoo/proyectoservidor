<?php
session_start();
include_once 'conexion_gestor.php';
if(isset($_SESSION['gestor'])) {

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Gestion Pedidos</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


</head>
<body>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/bootstrap.js" type="text/javascript"></script>

<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">ProyectoDAW</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="menu_gestor.php">Home</a></li>

            <li class="dropdown">
                <a class="dropdown-toggle active" data-toggle="dropdown" href="#">Clientes
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="gestion_clientes.php">Gestionar Clientes</a></li>
                    <li><a href="ver_solicitudes.php">Ver Solicitudes Pendientes</a></li>

                </ul>
            </li>

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Pedidos
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="hacer_pedido_admin.php">Realizar Pedido</a></li>
                    <li><a href="gestion_pedidos.php">Gestionar Pedidos</a></li>
                    <li><a href="#">Procesar Pedidos a Albaran</a></li>

                </ul>
            </li>

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Albaranes
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="gestion_pedidos.php">Gestionar Albaranes</a></li>
                    <li><a href="#">Procesar Albaran a Factura</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Facturas
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="gestion_pedidos.php">Gestionar Facturas</a></li>
                    <li><a href="#">Procesar Pedidos a Albaran</a></li>

                </ul>
            </li>


        </ul>
        <ul class="nav navbar-nav navbar-right">
            <!--                <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
            <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Cerrar Sesión</a></li>
        </ul>
    </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <?php
            $conexion = conectar();


            if(isset($_GET['cliente'])) {

                $_SESSION['cliente'] = $_GET['cliente'];

                function sacarcodcliente($nombre,$conexion){
                    $sql = "SELECT cod_cliente FROM clientes WHERE Nombre LIKE '$nombre'";
                    $res = $conexion->query($sql);
                    $dato = $res->fetch_assoc();
                    return $dato['cod_cliente'];
                }

                function estaenalbaran($cod_pedido,$conexion){

                    $sql = "SELECT * FROM lineas_albaran WHERE cod_pedido=$cod_pedido";
                    $ro = $conexion->query($sql);
                    $dato = $ro->num_rows;
                    
                    if($dato!=0){
                        return true;
                    }else{
                        return false;
                    }


                }

                $codigo = sacarcodcliente($_SESSION['cliente'],$conexion);
                $sql = "SELECT * FROM pedidos WHERE cod_cliente = $codigo";
                $resultado = $conexion->query($sql);
                $mostrar = "";
                echo "<h1>Pedidos del cliente: ".$_SESSION['cliente']."</h1>";
                while ($linea = $resultado->fetch_assoc()) {

                    $mostrar .= "<table class='table table-bordered text-center'><tr>
    <th class='text-center label-primary'>CODIGO PEDIDO</th>
    <th class='text-center label-primary'>CODIGO CLIENTE</th>
    <th class='text-center label-primary'>FECHA PEDIDO</th>
    <th class='text-center label-primary'>MODIFICAR</th>
    <th class='text-center label-primary'>ELIMINAR</th>
    </tr>";


                    $mostrar .= "<tr><td>".$linea['cod_pedido']."</td><td>" . $linea['cod_cliente'] . "</td><td>" . $linea['fecha'] .
                        "</td>
                    
                    <td><form method='post' action='modificar_pedido.php'>
                     
                        <input class='btn btn-primary' type='submit' name='modificar' id='modificar' value='Modificar'>
                        <input type='hidden' name='cod' id='cod' value=" . $linea['cod_pedido'] . ">
                                              
                        </form>
                    </td><td>";


                    if(estaenalbaran($linea['cod_pedido'],$conexion)==false) {
                        $mostrar .= "<form method='post' action='eliminar_pedido.php'>
                     
                        <input class='btn btn-danger' type='submit' name='eliminar' id='eliminar' value='Eliminar'>
                        <input type='hidden' name='cod' id='cod' value=" . $linea['cod_pedido'] . ">
                                              
                        </form>
                    ";
                    }

                    $mostrar.= "</td>";
                    $sqllineas = "SELECT * FROM lineas_pedidos WHERE cod_pedido=".$linea['cod_pedido'];
                    $ro = $conexion->query($sqllineas);
                    while($linea_pedido = $ro->fetch_assoc()){
                        $mostrar.= "</table><table class='table table-bordered text-center'><tr>
    <th class='text-center'>NUM_LINEA</th>
    <th class='text-center'>COD_PEDIDO</th>
    <th class='text-center'>COD_ARTICULO</th>
    <th class='text-center'>CANTIDAD</th>
    <th class='text-center'>USUARIO GESTION</th>
    </tr>
    <td>".$linea_pedido['num_linea_pedido']."</td>
    <td>".$linea_pedido['cod_pedido']."</td>
    <td>".$linea_pedido['cod_articulo']."</td>
    <td>".$linea_pedido['cantidad']."</td>
    <td>".$linea_pedido['usuario_gestion']."</td>
    </table>";
                    }

        $mostrar .= "<hr>";


                }

                echo $mostrar;
            }else{

                $consultar = "SELECT nombre,nick FROM clientes";
                $res = $conexion->query($consultar);




                echo "<div class=\"form-group\"><label for=\"sel1\">Ver pedidos de:</label><form action='gestion_pedidos.php' method='get' >";
                echo "<select class=\"form-control\" id='cliente' name='cliente'>";
                while($linea = $res->fetch_assoc()){
                    echo "<option>".$linea['nombre']."</option>";

                }

                echo "<input type='submit' class='btn btn-primary' name='enviar' id='enviar' value='Seleccionar'></select></form></div>";

            }


            }

            ?>
        </div>
    </div>
</div>