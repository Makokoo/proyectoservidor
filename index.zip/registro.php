<?php
include_once 'funciones.php';
?>
<html>
<body>
<link rel="stylesheet" href="bootstrap.css" type="text/css">

<?php



?>
<legend></legend>
<!--
<h1 class="h1 col-md-offset-5">Formulario de Solicitud</h1>
-->

<div class="panel panel-primary">
    <div class="panel-heading">Formulario de Registro</div>
    <form class="form-horizontal" action="registro.php" method="post">
        <fieldset>

            <!-- Form Name -->
            <legend></legend>



            <!-- Text input-->
            <div class="form-group">
                <label class="col-md-4 control-label" for="textinput">Nombre</label>
                <div class="col-md-4">
                    <input name="nombre" id="nombre" type="text" placeholder="Insertar nombre"  class="form-control input-md">
                </div>
            </div>


            <!-- Usuario -->

            <div class="form-group">
                <label class="col-md-4 control-label" for="textinput">Nick</label>
                <div class="col-md-4">
                    <input name="nick" id="nick" type="text" placeholder="Insertar nick"  class="form-control input-md">
                </div>
            </div>

            <!-- Password input-->
            <div class="form-group">
                <label class="col-md-4 control-label" for="passwordinput">Contraseña</label>
                <div class="col-md-4">
                    <input  name="pass" id="pass" type="password" placeholder="Insertar contraseña"  class="form-control input-md">
                </div>
            </div>

            <!-- Button -->
            <div class="form-group">
                <label class="col-md-4 control-label" for="singlebutton"></label>
                <div class="col-md-4">
                    <input class="btn btn-default" type="submit" id="enviar" name="enviar" value="Enviar Solicitud">
                </div>
            </div>

        </fieldset>
    </form>

</div>
<?php

if(isset($_POST['enviar'])) {
    if ($_POST['nombre']!=="" && $_POST['nick']!=="" && $_POST['pass']!=="") {
        //if (isset($_POST['nombre']) && isset($_POST['cif']) && isset($_POST['razon']) && isset($_POST['telf']) && isset($_POST['mail']) && isset($_POST['nick']) && isset($_POST['pass'])) {

        function existenick($nick){
            $sql = "SELECT * from clientes WHERE nick LIKE '$nick'";
            $conexion = conectar();
            $res = $conexion->query($sql);
            $dato = $res->num_rows;

            if($dato==1){
                return true;
            }else{
                return false;
            }

        }


        $nombre = $_POST['nombre'];
        $nick = $_POST['nick'];
        $pass = $_POST['pass'];



        if(existenick($nick)==false){

            $conexion = conectar();

            if($conexion) {

                $sql = "INSERT INTO clientes(Nombre,nick,pass) VALUES ('$nombre','$nick','$pass')";

                $conexion ->query($sql);

                echo "<div class='form-group'><div class='col-md-4 col-md-offset-4'>";
                echo "<p class='alert-success'>Se ha registrado correctamente.</p>";
                echo "<a href='index.php'>Haga click aquí para comenzar su compra</a>";
                echo "</div></div>";

            }
        }else{
            echo "<div class='form-group'><div class='col-md-4 col-md-offset-4'>";
            echo "<p class='alert-danger'>Ya existe ese nick en la base de datos, pruebe otro.</p>";
            echo "</div></div>";
        }



    } else {
        echo "<div class='form-group'><div class='col-md-4 col-md-offset-4'>";
        echo "<p class='alert-danger'>Debe rellenar todos los campos del formulario</p>";
        echo "</div></div>";
    }

}
?>





</body>
</html>