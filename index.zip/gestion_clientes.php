<!DOCTYPE html>
<html lang="en">

<head>
    <title>Menu Gestor</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">

</head>
<body>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/bootstrap.js" type="text/javascript"></script>
<?php
session_start();
include_once 'conexion_gestor.php';
if(isset($_SESSION['gestor'])) {

    ?>


    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">ProyectoDAW</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="menu_gestor.php">Home</a></li>

                <li class="dropdown">
                    <a class="dropdown-toggle active" data-toggle="dropdown" href="#">Clientes
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="gestion_clientes.php">Gestionar Clientes</a></li>
                        <li><a href="ver_solicitudes.php">Ver Solicitudes Pendientes</a></li>

                    </ul>
                </li>

                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Pedidos
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="hacer_pedido_admin.php">Realizar Pedido</a></li>
                        <li><a href="gestion_pedidos.php">Gestionar Pedidos</a></li>
                        <li><a href="#">Procesar Pedidos a Albaran</a></li>

                    </ul>
                </li>

                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Albaranes
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="gestion_pedidos.php">Gestionar Albaranes</a></li>
                        <li><a href="#">Procesar Albaran a Factura</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Facturas
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="gestion_pedidos.php">Gestionar Facturas</a></li>
                        <li><a href="#">Procesar Pedidos a Albaran</a></li>

                    </ul>
                </li>


            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!--                <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Cerrar Sesión</a></li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-4 col-lg-offset-4">
                    <a href="ver_solicitudes.php"><button class="btn"><i class="glyphicon glyphicon-list"></i> Ver Solicitudes Pendientes</button></a>
                    <a href="crear_cliente.php"><button class="btn"><i class="glyphicon glyphicon-plus-sign"></i> Registrar Nuevo Cliente</button></a>
                </div>
                <br>
                <br>
                <br>
                <br>
                <div class="col-lg-12 col-lg-offset-0">
            <div id="loader" class="text-center"> <img src="loader.gif"></div>
            <div class="outer_div"></div><!-- Datos ajax Final -->
        </div>
    </div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->

</body>
</html>
<script>
    $(document).ready(function(){
        load(1);
    });

    function load(page){
        var parametros = {"action":"ajax","page":page};
        $("#loader").fadeIn('slow');
        $.ajax({
            url:'tabla_clientes.php',
            data: parametros,
            beforeSend: function(objeto){
                $("#loader").html("<img src='loader.gif'>");
            },
            success:function(data){
                $(".outer_div").html(data).fadeIn('slow');
                $("#loader").html("");
            }
        })
    }
</script>


    </body>

    </html>
    <?php
}else{
    echo "No puede acceder a esta pagina sin iniciar sesión como gestor, puede iniciar sesión
    <a href='login_gestor.php'>haciendo click aquí</a>";

}
?>